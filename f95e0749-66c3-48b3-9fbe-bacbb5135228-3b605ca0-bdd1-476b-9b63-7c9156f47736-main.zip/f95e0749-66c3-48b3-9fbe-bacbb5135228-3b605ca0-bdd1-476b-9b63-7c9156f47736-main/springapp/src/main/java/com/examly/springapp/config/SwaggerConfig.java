package com.examly.springapp.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
        @Bean
        public OpenAPI customerOpenAPI(){
                return new  OpenAPI()
                .info(new Info()
                .title("My API")
                .version("1.0")
                .description("API documentation using swagger"));
        }

        }